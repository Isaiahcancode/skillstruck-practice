response = int(input("enter a number"))
if response >= 48:
    print("You can ride the roller coaster.")
else:
   print("You can't ride the roller coaster.")