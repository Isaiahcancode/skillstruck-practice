#comment goes here
morning = input("what do you do in morning?")
print(morning)
afternoon = input("what do you do in morning?")
print(afternoon)
evening = input("what do you do in morning?")
print(evening)