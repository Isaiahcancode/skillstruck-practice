string1 = 
string2 = 
string3 = 

together = 

print()