reasons = ["time", "money", "power"]
print(reasons)