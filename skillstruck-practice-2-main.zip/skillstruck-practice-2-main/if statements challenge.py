number = int(input("enter a number"))
if number >= 12:   
    print("Good Day!")
else:
    print("Good Morning!")