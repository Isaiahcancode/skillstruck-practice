number1 = int(input("enter number"))
number2 = int(input("enter number"))
if number1 > number2:
    print(number2)
else:
    print(number1)