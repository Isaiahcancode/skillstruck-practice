chickens = 3
geese = 7

if geese > chickens:
    print("there are more geese")
else:
    print("there are more chicken")