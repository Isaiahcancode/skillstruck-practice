friends = ["jhon", "web", "tyler"]
print(friends)